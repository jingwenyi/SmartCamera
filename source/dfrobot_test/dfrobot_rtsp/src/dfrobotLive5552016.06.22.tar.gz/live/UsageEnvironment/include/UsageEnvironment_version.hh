// Version information for the "UsageEnvironment" library
// Copyright (c) 1996-2016 Live Networks, Inc.  All rights reserved.

#ifndef _USAGEENVIRONMENT_VERSION_HH
#define _USAGEENVIRONMENT_VERSION_HH

#define USAGEENVIRONMENT_LIBRARY_VERSION_STRING	"2016.05.20"
#define USAGEENVIRONMENT_LIBRARY_VERSION_INT		1463702400

#endif
